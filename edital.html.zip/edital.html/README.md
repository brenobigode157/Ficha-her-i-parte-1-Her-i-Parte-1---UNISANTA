# ⚔️ Ficha de Herói — Link (Cavaleiro de Hyrule)

- Projeto prático (Parte 1) desenvolvido para a disciplina de HTML e CSS da UNISANTA, utilizando os princípios do UI/UX.

- A ideia é fazer um layout de RPG para um personagem em forma de página web.


## 🔗 Link do Protótipo

- Protótipo: https://canva.link/f2remq9sf4gk23y


## 🤖 Tecnologias utilizadas

- HTML: Utilizado para estruturar o conteúdo e separar as seções da página.
- CSS: Usado para as decorações da página, tais como definir as cores, fontes e efeitos visuais.
- Google Fonts: Apliciado para adicionar a fonte MedievalSharp, que combina com a temática medieval do jogo.


## 🛡️ Identidade do Personagem

- Nome: Link
- Classe: Cavaleiro de Hyrule
- Universo: The Legend of Zelda
- Breve Biografia: Descendente dos Hylians, sempre dedicado a proteger o reino de Hyrule e a Princesa Zelda.


## 🎨 Decisões de UI/UX 

1 -> Hierarquia Visual:
   - O nome do herói no cabeçalho e os títulos das seções possuem tamanhos maiores para direcionar o olhar do usuário na ordem já estabelecida para um leitura correta.

2 -> Contraste e Legibilidade:
   - Utilização de fundo verde escuro com textos em branco e amarelo no nav ao passar o mouse em cima, isto para ter uma semelhança com o universo de Hyrule e garantir alto contraste para uma leitura sem uma bagunça visual.

3 -> Consistência:
   - Todos os elementos da página mantêm a mesma identidade visual, sendo elas bordas arredondadas nas imagens colocadas e eespaçamentos padronizados.

4 -> Affordance e Feedback:
   - Os links do menu de navegação alteram a cor de fundo e a cor do texto ao passar o mouse por cima, mostrando que são elementos interativos.
